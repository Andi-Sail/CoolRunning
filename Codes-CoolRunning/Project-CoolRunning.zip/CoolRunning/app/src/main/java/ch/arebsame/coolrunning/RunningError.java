package ch.arebsame.coolrunning;

/**
 * the possible errors while the user is running
 */
public enum RunningError {
    correct,
    tooSlow,
    tooFast,
}
